# Copyright (c) 2021 - Pustaka Koding - Indra Styawantoro. All rights reserved.


# Permissions

- Private use
- Modification
- Distribution


# Limitations

- Commercial use
- Liability
- Warranty
