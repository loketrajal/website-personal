<?php
// 1. Copy dan paste file env.copy.php dan ubah nama menjadi env.php
// 2. Ubah konfigurasi sesuai dengan server

putenv("IP_SERVER=127.0.0.1");

putenv("DB_HOST=127.0.0.1");
putenv("DB_USERNAME=root");
putenv("DB_PASSWORD=");
putenv("DB_DATABASE=aplikasi_antrian_v2");
