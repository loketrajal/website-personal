<style>
      @media print {
    body {
        background-color: <?= $data['warna_primary'] ? $data['warna_primary'] : '#6B5935' ?>;
    }
    .buttons-container {
        display: none; /* Hide buttons when printing */
    }
}

}
